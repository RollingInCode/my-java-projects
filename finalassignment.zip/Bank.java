package finalassignment;

public class Bank extends Downtown { // ProduceItem derived from GenericItem
	Bank x = new Bank();
   public void DaysofOpen(String availability) {
      schedule = availability;
   }

   public String whenItOpens() {
      return schedule;
   }
	public Bank() {
		schedule = "Weekends M-F 9am-5pm";
	}
	
   public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

public String toString() {
	   return (String.valueOf(x));
   }
   
   private String schedule;

}

/*
public class ClassDerivationEx {
	   public static void main(String[] args) {
	      GenericItem miscItem = new GenericItem();
	      ProduceItem perishItem = new ProduceItem();

	      miscItem.setName("Smith Cereal");
	      miscItem.setQuantity(9);
	      miscItem.printItem();

	      perishItem.setName("Apples");
	      perishItem.setQuantity(40);
	      perishItem.setExpiration("May 5, 2012");
	      perishItem.printItem();

	      System.out.println("  (Expires: " + perishItem.getExpiration() + ")");
	   }
	}

*/