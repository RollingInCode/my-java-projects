package finalassignment;

public class City extends Kingdom { //
	City x = new City();
   public void government(String typeOf) {
      classification = typeOf;
   }

   public String getExpiration() {
      return classification;
   }
	public City() {
		classification = "Jonsville";
	}
	
   public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

public String toString() {
		return (String.valueOf(x));
	}
   
   private String classification;

}
