package finalassignment;

public class Downtown extends Kingdom { // ProduceItem derived from GenericItem
	Downtown x = new Downtown();
   public void government(String typeOf) {
	      classification = typeOf;
	   }

	   public String getExpiration() {
	      return classification;
	   }
		public Downtown() {
			classification = "Partle Street";
		}
		
	   public String getClassification() {
			return classification;
		}

		public void setClassification(String classification) {
			this.classification = classification;
		}

	public String toString() {
			return (String.valueOf(x));
		}
	   
	   private String classification;

	}