package finalassignment;

public abstract class Employees extends Kingdom implements Sims
{
	protected int x;
	
	
	public abstract void print();
	
	public void setX(int a)
	{
		x = a;
	}
	public int getX() {
		return x;
	}

	public Employees() {
		x = 0;
	}
	public String toString() {
		return (String.valueOf(x));
	}
}