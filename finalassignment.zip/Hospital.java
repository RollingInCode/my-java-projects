package finalassignment;

public class Hospital extends City { // ProduceItem derived from GenericItem
	Hospital x = new Hospital();
   public void Capacity(String people) {
      classification = people;
   }

   public String typeOf() {
      return classification;
   }
	public Hospital() {
		classification = "Service Hospital";
	}
	
   public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

public String toString() {
		return (String.valueOf(x));
	}
   
   private String classification;

}

/*
public class ClassDerivationEx {
	   public static void main(String[] args) {
	      GenericItem miscItem = new GenericItem();
	      ProduceItem perishItem = new ProduceItem();

	      miscItem.setName("Smith Cereal");
	      miscItem.setQuantity(9);
	      miscItem.printItem();

	      perishItem.setName("Apples");
	      perishItem.setQuantity(40);
	      perishItem.setExpiration("May 5, 2012");
	      perishItem.printItem();

	      System.out.println("  (Expires: " + perishItem.getExpiration() + ")");
	   }
	}
*/

