package finalassignment;

public class Kingdom {
	Kingdom x = new Kingdom();
	public void setName(String newName) {
		kingdomName = newName;
}

		public void King(int numberOf) {
        itemName = numberOf;
		}

	   public void printItem() {
	      System.out.println(itemName + " " + itemName);
	   }
		public Kingdom() {
			kingdomName = "Jon's Castle";
			itemName = 1;
		}
		
	   public String getKingdomName() {
			return kingdomName;
		}

		public void setKingdomName(String kingdomName) {
			this.kingdomName = kingdomName;
		}

	public String toString() {
			return (String.valueOf(x));
		}

	   protected int itemName;
	   protected String kingdomName;
	}

/*
public class Kingdom {
	   public static void main(String[] args) {
	      King name = new King();
	      ProduceItem perishItem = new ProduceItem();

	      name.setName("Will Smith");
	      name.setQuantity(9);
	      name.printItem();

	      perishItem.setName("Apples");
	      perishItem.setQuantity(40);
	      perishItem.setExpiration("May 5, 2012");
	      perishItem.printItem();

	      System.out.println("  (Expires: " + perishItem.getExpiration() + ")");
	   }
	}

*/

