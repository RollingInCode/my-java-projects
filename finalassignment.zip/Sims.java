package finalassignment;

public interface Sims {
	public void windowOpened();
}
