package finalassignment;

public class Supermarket extends City { // ProduceItem derived from GenericItem
	Supermarket x = new Supermarket();
   public void Capacity(String people) {
      classification = people;
   }

   public String sizeOf() {
      return classification;
   }
	public Supermarket() {
		classification = "Big Supermarket - 105,000 sq ft";
	}
   
   public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

public String toString() {
		return (String.valueOf(x));
	}

   private String classification;

}