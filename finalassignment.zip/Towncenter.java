package finalassignment;

public class Towncenter extends Downtown { // ProduceItem derived from GenericItem
	Towncenter x = new Towncenter();
   public void DaysofOpen(String availability) {
      schedule = availability;
   }

   public String whenItOpens() {
      return schedule;
   }
	public Towncenter() {
		schedule = "Weekends M-F 9am-5pm";
	}
   public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

public String toString() {
		return (String.valueOf(x));
	}

   private String schedule;

}
